ICT/SMC Quiz Android project
============================

Project này đóng gói trang HTML trắc nghiệm thành ứng dụng Android chạy offline.

Cách tạo APK:
1. Trên máy tính, cài Android Studio từ https://developer.android.com/studio
2. Giải nén ICT_SMC_Quiz_Android.zip.
3. Android Studio > Open > chọn thư mục ICT_SMC_Quiz_Android.
4. Chờ Gradle Sync hoàn tất. Nếu được hỏi cài Android SDK 35 hoặc Gradle/JDK phù hợp, chọn cài đặt.
5. Vào Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Khi build xong, bấm Locate ở thông báo hiện ra. APK debug thường nằm tại:
   app/build/outputs/apk/debug/app-debug.apk
7. Chuyển APK sang điện thoại Android, mở tệp và cho phép cài ứng dụng từ nguồn đó nếu Android yêu cầu.

Lưu ý:
- Đây là project Android Studio, chưa phải file APK đã biên dịch.
- Bạn cần máy tính để build APK theo cách này. Chỉ có điện thoại thì có thể khó build trực tiếp.
- Ứng dụng dùng WebView và file HTML nhúng nên bài kiểm tra có thể chạy offline.
- Chỉ cài APK do chính bạn tạo hoặc tin cậy; Android có thể hiện cảnh báo khi cài ngoài Play Store.
