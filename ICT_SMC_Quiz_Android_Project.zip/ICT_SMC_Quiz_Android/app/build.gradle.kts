plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "vn.ictsmc.quiz"
    compileSdk = 35

    defaultConfig {
        applicationId = "vn.ictsmc.quiz"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
